
import Foundation
import SpriteKit
class Fine: SKScene {
    override func didMove(to view: SKView) {
        let dialogo = SKLabelNode(fontNamed: "Chalkduster")

        dialogo.text = "The Be Continued"
        dialogo.lineBreakMode = .byWordWrapping
        dialogo.numberOfLines = 2
        dialogo.fontSize = 20
        dialogo.horizontalAlignmentMode = .center
        dialogo.fontColor = SKColor.white
        dialogo.position = CGPoint(x: frame.midX, y: frame.midY-20)
        addChild(dialogo)

    }


}
