import SpriteKit

struct gameplayCategory {
    let None:UInt32 = 0
    let gionnyCategory:UInt32 = 0x1 << 0 // 1
    let goblinCategory:UInt32 = 0x1 << 1 // 2
    let groundCategory:UInt32 = 0x1 << 2 // 4
}

class goblinClass: SKSpriteNode {
    var goblin: SKSpriteNode?
    var shield: Int = 10
    var attack = 5
    let category = gameplayCategory()

    var isAlive : Bool = true


    convenience init(position: CGPoint) {
        self.init()
        goblin = SKSpriteNode()
        if let goblin = goblin {
            goblin.position = position
            goblin.size = CGSize(width: 200, height: 200)
            goblin.physicsBody = SKPhysicsBody(rectangleOf: goblin.size)

            goblin.physicsBody?.isDynamic = true
            goblin.physicsBody?.affectedByGravity = true
            goblin.physicsBody?.categoryBitMask = category.goblinCategory
            goblin.physicsBody?.contactTestBitMask = category.groundCategory | category.gionnyCategory
            goblin.physicsBody?.collisionBitMask = category.groundCategory
            goblin.texture = SKTexture(imageNamed: "goblin")
            addChild(goblin)
        }
    }
}
