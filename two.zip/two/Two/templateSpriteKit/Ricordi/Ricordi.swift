//
//  Ricordi.swift
//  prova55
//
//  Created by Stefano Leva on 16/04/22.
//

import Foundation
import SpriteKit

class Ricordi: SKScene{
    var sound = SKAudioNode()
    var counter=0
    let text = SKLabelNode(fontNamed: "Chalkduster")
    
    override func didMove(to view: SKView) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) { [self] in
            self.sound = SKAudioNode(fileNamed: "Ricordi")
            scene?.addChild(sound)
        }
        
           text.name = "testo"
           Dialogo(testo: "Hey mom! Look at this kite I've just built! \nCome outside and look how it flies!")
       
       }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
               counter = counter + 1
               Azioni(Counter: counter)
       }
    
    func Azioni(Counter: Int){
            switch Counter{
               
                case 1:
                    Dialogo(testo:"Wonderful.")
                    let face1 = childNode(withName: "face") as! SKSpriteNode
                    face1.texture = SKTexture(imageNamed: "Mamma")
                    
                
                case 2:
                    Dialogo(testo: "...")
                    let face2 = childNode(withName: "face") as! SKSpriteNode
                    face2.texture = SKTexture(imageNamed: "Layer 1_child_prot_4")
                    let body = childNode(withName: "child_prot") as! SKSpriteNode
                    body.texture = SKTexture(imageNamed:"Layer 1_child_prot_3")
                
            case 3:
                let transition: SKTransition = SKTransition.fade(withDuration: 1.5)
                let Ricordi2 = SKScene(fileNamed: "Ricordi2")
                Ricordi2?.scaleMode = .aspectFit
                view?.presentScene(Ricordi2!,transition: transition)
                default: break
            }
        }
    
    func Dialogo(testo : String){
                //dialogo
                //tolgo il precedente
                text.removeFromParent()
                //metto il nuovo
                text.text = testo
                text.lineBreakMode = .byWordWrapping
                text.numberOfLines = 2
                text.fontSize = 20
                text.horizontalAlignmentMode = .left
                text.fontColor = SKColor.white
                text.position = CGPoint(x: -246, y: -150)
                addChild(text)

            }


}
