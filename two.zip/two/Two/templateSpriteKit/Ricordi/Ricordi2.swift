//
//  Ricordi2.swift
//  prova55
//
//  Created by Stefano Leva on 16/04/22.
//

import Foundation
import SpriteKit

class Ricordi2: SKScene{
    var sound = SKAudioNode()
    var counter=0
    let text = SKLabelNode(fontNamed: "Chalkduster")
    
    override func didMove(to view: SKView) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [self] in
            self.sound = SKAudioNode(fileNamed: "Ricordi")
            scene?.addChild(sound)
        }
           text.name = "testo"
           Dialogo(testo: "Mom, can I sleep with you? \nI had a nightmare and I'm scared...")
       
       }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
               counter = counter + 1
               Azioni(Counter: counter)
       }
    
    func Azioni(Counter: Int){
            switch Counter{
               
                case 1:
                    Dialogo(testo:"(Inside the room) Don't bother me! \nI've more important things to do tomorrow! Go back to your room!")
                    let face1 = childNode(withName: "face") as! SKSpriteNode
                    face1.texture = SKTexture(imageNamed: "Mamma")
                    
                
                case 2:
                    Dialogo(testo: "...")
                    let face2 = childNode(withName: "face") as! SKSpriteNode
                    face2.texture = SKTexture(imageNamed: "Layer 1_child_prot_8")
                    let body = childNode(withName: "child_prot") as! SKSpriteNode
                    body.texture = SKTexture(imageNamed:"Layer 1_child_prot_7")
                
                case 3:
                    let transition: SKTransition = SKTransition.fade(withDuration: 1.5)
                    let PostRicordi = SKScene(fileNamed: "PostRicordi")
                    PostRicordi?.scaleMode = .aspectFit
                    view?.presentScene(PostRicordi!,transition: transition)
                
                default: break
            }
        }
    
    func Dialogo(testo : String){
                //dialogo
                //tolgo il precedente
                text.removeFromParent()
                //metto il nuovo
                text.text = testo
                text.lineBreakMode = .byWordWrapping
                text.numberOfLines = 2
                text.fontSize = 20
                text.horizontalAlignmentMode = .left
                text.fontColor = SKColor.white
                text.position = CGPoint(x: -246, y: -150)
               // text.zPosition=5
                addChild(text)

            }


}
