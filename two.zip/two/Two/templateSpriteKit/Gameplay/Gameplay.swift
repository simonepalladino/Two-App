//
//  GameScene.swift
//  templateSpriteKit
//
//  Created by Lorenzo di Palo on 07/04/22.
//

import SpriteKit
import GameplayKit

class Gameplay: SKScene, SKPhysicsContactDelegate {
    var sound = SKAudioNode()
    let move = SKAction.moveBy(x: 120, y: 0, duration: 2)


    var Cam = SKCameraNode()
    
    var goblinIsAlive : Bool = true
    
    let goblinRunTextureArray: [SKTexture] =
    [SKTexture(imageNamed: "goblin2"),
     SKTexture(imageNamed: "goblin3"),
     SKTexture(imageNamed: "goblin4"),
     SKTexture(imageNamed: "goblin5")]
    let goblinRunArray: [SKTexture] =
    [
     SKTexture(imageNamed: "goblin4"),
     SKTexture(imageNamed: "goblin5"),
     SKTexture(imageNamed: "goblin")]
    
    var goblinRunAction = SKAction()
    
    var btnAttack = SKSpriteNode()
    
    var counter : Int = 0
    
    var collisionGoblinPlayer = false
    
    var contactRapid = false
    
    let healthBar = HealthBar(color: SKColor.red, size:CGSize(width:200, height:40))
    
    
    var damageGlobal = 0.0
    
    ///variabili da cambiare allo switch tone
    var playerHealth = 20
    var playerAttack = 5
    var goblinAttack = 5
    var lowHighTone: Float = 4
    
    var isPlayerAlive = true
    
    let gameOver = SKSpriteNode(imageNamed: "Layer1_protagonist_01")
    
    var Ground = SKSpriteNode()
    
    let None:UInt32 = 0
    let gionnyCategory:UInt32 = 0x1 << 0 // 1
    let goblinCategory:UInt32 = 0x1 << 1 // 2
    let groundCategory:UInt32 = 0x1 << 2 // 4
    
    var gionny = SKSpriteNode()
    var goblinArray : [goblinClass] = Array()
    
    
    var lowTone : Bool = true
    var actionRunGionny = SKAction()
    var currentImpulse: Int = 1000
    var startingTime: TimeInterval = 0
    var groundTouched = true
    var walking = false
    
    
    var timer: Timer?
    var timer2: Timer?
    var timer3: Timer?
    
    
    
    override func didMove(to view: SKView) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) { [self] in
            self.sound = SKAudioNode(fileNamed: "Gameplayp")
            scene?.addChild(sound)
        }
        
        Cam = childNode(withName: "camera") as! SKCameraNode
        physicsWorld.contactDelegate = self
        gameOver.zRotation = -225
        gameOver.size = CGSize(width: 160, height: 160)
        gameOver.position = CGPoint(x: 0, y: 0)
        gionny = childNode(withName: "gionny") as! SKSpriteNode
        healthBar.position = CGPoint(x: -320, y: 160)
        btnAttack = camera!.childNode(withName: "attacco") as! SKSpriteNode
        btnAttack.isHidden = true
        camera?.addChild(healthBar)
        
        Ground = childNode(withName: "Ground") as! SKSpriteNode
        Ground.physicsBody = SKPhysicsBody(rectangleOf: Ground.size)
        Ground.physicsBody?.affectedByGravity = false
        Ground.physicsBody?.isDynamic = false
        Ground.physicsBody?.categoryBitMask = groundCategory
        Ground.physicsBody?.contactTestBitMask = gionnyCategory
        Ground.physicsBody?.collisionBitMask = goblinCategory | gionnyCategory
        Ground.physicsBody?.allowsRotation = false
        
        goblinRunAction = SKAction.animate(with: goblinRunArray , timePerFrame: 0.1)
        

        //gionny = childNode(withName: "gionny") as! SKSpriteNode
        // questa va nel touch hold
        gionny.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 200, height: 250))
        gionny.physicsBody?.isDynamic = true
        gionny.physicsBody?.affectedByGravity = true
        gionny.physicsBody?.categoryBitMask = gionnyCategory
        gionny.physicsBody?.contactTestBitMask = goblinCategory
        gionny.physicsBody?.collisionBitMask =   groundCategory | goblinCategory
        //spawnGoblin()
        // array che contiene tutti i goblin
       /* let g = SKSpriteNode(imageNamed: "goblin")
        g.position =  CGPoint(x: 100, y: 0)
        scene?.addChild(g)
        g.run(SKAction.repeatForever(goblinRunAction))*/
        
       for i in 0...10{
               let s = i*1000
               AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: Double(s),Y: 270,L: 600,H:600,Forever: true)

            goblinArray.append(goblinClass(position: CGPoint(x: i*1000, y: 0), Animazione: goblinRunAction))
           
            goblinArray[i].name = String(i)
            
           
            
            scene?.addChild(goblinArray[i])
           goblinArray[i].run(SKAction.repeatForever(SKAction.sequence([move,move.reversed()])))
        }
        
    }
    override func update(_ currentTime: CFTimeInterval)
    {
        Cam.position.x = gionny.position.x
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        /*
        if (node.name == "Jump" ) {
            if (groundTouched == true){
                gionny.physicsBody?.applyImpulse(CGVector(dx: 0, dy: currentImpulse))
                gionny.removeAllActions()
                actionRunGionny = SKAction(named: "jump")!
                gionny.run(actionRunGionny)
            }
        }*/
        // movimento avanti e dietro
        if (node.name == "right1") {
            walking = true
            timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true, block: {
                t in
                if self.lowHighTone == 4 {
                    self.gionnyRun(named: "run")
                } else {
                    self.gionnyRun(named: "runHigh")
                }
            })
        }
        if (node.name == "left1") {
            walking = true
            
            timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true, block: {
                t in
                if self.lowHighTone == 4 {
                    self.gionnyRun(named: "back")
                } else {
                    self.gionnyRun(named: "backHigh")
                }
            })
        }
        if (node.name == "attacco") {
            walking = true
            btnAttack.texture = SKTexture(imageNamed: "Layer 1_attack_2")
            timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: false, block: {
                t in
                if self.lowHighTone == 4 {
                    self.gionnyRun(named: "attack")
                } else {
                    self.gionnyRun(named: "attackHigh")
                }
            })
            gionnyAttacck()
            
        }
        if (node.name == "GameOver") {
            let transition: SKTransition = SKTransition.fade(withDuration: 1.3)
            let Gameplay = SKScene(fileNamed: "Gameplay")
            Gameplay?.scaleMode = .aspectFit
           view?.presentScene(Gameplay!,transition: transition)
        }
        //let sound = SKAction.playSoundFileNamed("passi", waitForCompletion: false)
        //let move = SKAction.moveBy(x: 50, y: 0, duration: 0.5)
        //let mirror = SKAction.scaleX(to: 1.0, duration: 0.1)
        /*let rightBtnPar = scene?.childNode(withName: "right1") as! SKSpriteNode
         let rightText2 = SKTexture(imageNamed: "Layer1_right_btn2")
         rightBtnPar.texture=rightText2*/
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        walking = false
        timer?.invalidate()
        btnAttack.texture = SKTexture(imageNamed: "Layer 1_attack_1")
    }
    func gionnyRun(named: String){
        
        actionRunGionny = SKAction(named: named)!
        gionny.run(actionRunGionny)
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        var firstBody : SKPhysicsBody
        var secondBody : SKPhysicsBody
        if (contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask){
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        }
        else{
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        if (firstBody.categoryBitMask & gionnyCategory != 0  && secondBody.categoryBitMask & groundCategory != 0){
            groundTouched = true
            print("stato terreno: \(groundTouched)")
        }
        if ((firstBody.categoryBitMask & gionnyCategory != 0) && (secondBody.categoryBitMask & goblinCategory != 0)) {
            if let player = firstBody.node as? SKSpriteNode, let goblin = secondBody.node as? SKSpriteNode {
                
                btnAttack.isHidden = false
                goblin.isPaused = false
                contactRapid = true
              

                goblin.run(SKAction.repeatForever(SKAction.animate(with:goblinRunTextureArray , timePerFrame: 0.1)))
                
                timer3 = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: {
                    a in
                    self.goblinAlive(goblin: goblin)
                })
                
                timer2 = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {
                    t in
                    self.goblinDidCollideWithPlayer(goblin: goblin, player: player)
                })
            }
        }
    }
    func goblinDidCollideWithPlayer(goblin: SKSpriteNode, player: SKSpriteNode) {
        
        collisionGoblinPlayer = true
        //goblin.removeAllActions()
        playerHealth -= goblinAttack
        //healthNode.xScale -= 0.25
        healthBar.progress = CGFloat(1/lowHighTone)
        
        print("Hit")
        guard isPlayerAlive else {return}
        
        if playerHealth <= 0 {
            sound.removeFromParent()
            player.removeFromParent()
            goblin.isPaused = true
            timer?.invalidate()
            timer2?.invalidate()
            timer3?.invalidate()
            
            isPlayerAlive = false
            
         let schermo = SKSpriteNode(imageNamed: "Layer 1_retry_1")
            schermo.name = "GameOver"
            schermo.size = CGSize(width: 300, height: 200)
            schermo.position = CGPoint( x :  0 , y : 35)
            camera?.addChild(schermo)
        }
    }
    func didEnd(_ contact: SKPhysicsContact) {
        if (contact.bodyA.categoryBitMask == groundCategory) {
            groundTouched = false
            print("stato terreno: \(groundTouched)")
            
        }
        if (contact.bodyB.categoryBitMask == groundCategory){
            groundTouched = false
            print("stato terreno: \(groundTouched)")
            
        }
        if (contact.bodyA.categoryBitMask == goblinCategory) {
            if let goblin = contact.bodyA.node as? SKSpriteNode {
                timer2?.invalidate()
                guard collisionGoblinPlayer || contactRapid else{return}
                //goblinAction(goblin: goblin)
                goblin.isPaused = true
                btnAttack.isHidden = true
              //  goblin.run(SKAction.repeatForever(goblinRunAction))
                contactRapid = false
                collisionGoblinPlayer = false
                print("false")
            }
        }
        
        if (contact.bodyB.categoryBitMask == goblinCategory) {
            if let goblin = contact.bodyB.node as? SKSpriteNode {
                
                timer2?.invalidate()
                guard collisionGoblinPlayer || contactRapid else{return}
                goblin.isPaused = false
                goblin.removeAllActions()
                goblin.run(SKAction.repeatForever(goblinRunAction))
                btnAttack.isHidden = true
                contactRapid = false
                collisionGoblinPlayer = false
                print("false")
            }
        }
        
    }
    
    func gionnyAttacck(){
        print("vita goblin \(counter): \(goblinArray[counter].shield)")
        goblinArray[counter].shield -= playerAttack
        if (goblinArray [counter].shield <= 0){
            goblinIsAlive = false
            counter += 1
        }
        if ((counter > 2) && (counter%5)==0){
            print("\(lowHighTone)")
            changeTone()
        }
    }
    
    func goblinAlive(goblin: SKSpriteNode){
        if goblinIsAlive == false {
            btnAttack.isHidden = true
            goblinDead(goblin: goblin)
           // goblin.removeFromParent()
            timer2?.invalidate()
            timer3?.invalidate()
            goblinIsAlive = true
            if counter == 8 {
                let transition: SKTransition = SKTransition.fade(withDuration: 1.3)
                let Ricordi = SKScene(fileNamed: "Ricordi")
                Ricordi?.scaleMode = .aspectFit
               view?.presentScene(Ricordi!,transition: transition)
            }
        }
    }
    
    func AnimationoOnly(Name: String,numeroS: Int,X: Double,Y: Double,L: Double,H: Double,Forever: Bool) {
        var Img = SKSpriteNode()
        Img = SKSpriteNode(imageNamed: Name)
        Img.name=Name
        Img.zPosition = -100
        Img.size = CGSize(width: L, height: H)
        Img.position = CGPoint( x :  X , y : Y)
        scene?.addChild(Img)
        
        if numeroS  > 1 {
        var textureArray = [SKTexture]()
        let range = 1...numeroS
        for index in range{
            let textureName = Name+String(index)
            let texture = SKTexture(imageNamed: textureName)
            textureArray.append(texture)
        }
            let runAction = SKAction.animate(with: textureArray , timePerFrame: 0.5)
            if(Forever){
                Img.run(SKAction.repeatForever(runAction))
            }else{
                Img.run(runAction)
            }

        }
    }
    func changeTone(){
        if (lowHighTone == 4){
            playerAttack = 10
            playerHealth = 10
            lowHighTone = 2
        }
        else{
            playerAttack = 5
            playerHealth = 20
            lowHighTone = 4
        }
        
    }
    func goblinDead(goblin: SKSpriteNode){
        goblin.removeAllActions()
        goblin.physicsBody?.isDynamic = true
        goblin.physicsBody?.affectedByGravity = true
        goblin.physicsBody?.categoryBitMask = 0
        goblin.physicsBody?.contactTestBitMask = 0
        goblin.physicsBody?.collisionBitMask = groundCategory
        goblin.zRotation = 225
        goblin.removeFromParent()
        scene?.addChild(goblin)
    }
}
