import SpriteKit

class gionnyClass: SKSpriteNode {
    
    var LowTone: Bool = true
    var gionny = SKSpriteNode()
    func spawn() -> SKSpriteNode{
        gionny = childNode(withName: "gionny") as! SKSpriteNode
        return gionny
    }
}

