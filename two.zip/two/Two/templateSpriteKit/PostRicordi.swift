//
//  Spada.swift
//  templateSpriteKit
//
//  Created by Vincenzo Bastelli on 15/04/22.
//

import Foundation
import SpriteKit
class PostRicordi: SKScene {
    var Plays = SKSpriteNode()
    var Goblin = SKSpriteNode()
    var textureArray = SKTexture()
    var sound = SKAudioNode()
    let dialogo = SKLabelNode(fontNamed: "Chalkduster")
    var testa  = SKSpriteNode()
    var nomeD = SKLabelNode(fontNamed: "Chalkduster")
    var barra : [SKSpriteNode] = [SKSpriteNode(imageNamed: "Layer2_dw1"),SKSpriteNode(imageNamed: "Layer2_dw2"),SKSpriteNode(imageNamed: "Layer2_dw3")]
    var caunter = 0
    var CouterB = true
    var player = SKSpriteNode()
    var Cam = SKCameraNode()
    let posizioneCam = SKCameraNode()
    var pos = SKSpriteNode()
    
    override func didMove(to view: SKView) {
      //  DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [self] in}
        Cam = childNode(withName: "cameraP") as! SKCameraNode
        //per prendere il valore della posizione iniziale della camera
        posizioneCam.position.x = Cam.position.x
        
        AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: 170,Y: 53,L: 256,H: 256,Forever: true)
        AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: -400,Y: 51,L: 256,H: 256,Forever: true)
        

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [self] in
            self.BarraOnOff(Vedere: true)
            Dialogo(testo : "I...I did it.",Name : "Isaac")
        }

        
  
    }
    
    //azioni parte importante delle scene
    func Azioni (Counter: Int){
        switch caunter {
        case 1:
            player = childNode(withName: "Isaac") as! SKSpriteNode
            player.texture = SKTexture(imageNamed: "IsaacHS")
            Dialogo(testo : "I WON!!!",Name : "Isaac")
        case 2:
            Dialogo(testo : "WHAT DID YOU DO?!",Name : "Robin")
        case 3:
            nomeD.removeFromParent()
            dialogo.removeFromParent()
            testa.removeFromParent()
            BarraOnOff(Vedere: false)
            Cam.run(SKAction.moveBy(x: -200, y: 0, duration: 2))
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                Suono (Nome: "Scoperta",RimuoviVecchia: true,Stop: false)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [self] in
                self.BarraOnOff(Vedere: true)
                self.Dialogo(testo : "He deserved it! \nIt was me or him!",Name : "Isaac")
            }
        case 4:
            Dialogo(testo : "You killed him with no mercy! \nStay away from me!",Name : "Robin")
        case 5:
            CouterB = false
            Plays = childNode(withName: "Robin") as! SKSpriteNode
            Plays.run((SKAction.scaleX(to: -1, duration: 0.1)))
            Movimento(Name:"Robin",X: -580,Y: 0,Forever: false,Animation: "robinC",velocita: 2)
            
            Dialogo(testo : "Robin, wait!",Name : "Isaac")
            player.texture = SKTexture(imageNamed: "Layer1_prot13")
            Movimento(Name:"Isaac",X: -200,Y: 0,Forever: false,Animation: "LowToneC",velocita: 3.5)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5){[self] in
                nomeD.removeFromParent()
                dialogo.removeFromParent()
                testa.removeFromParent()
                BarraOnOff(Vedere: false)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { [self] in
                BarraOnOff(Vedere: true)
                self.Dialogo(testo : "Am I... a killer?",Name : "Isaac")
                CouterB = true
            }
        case 6:
            Dialogo(testo : "Maybe it's better to go back home...",Name : "Isaac")
            let Img = childNode(withName: "Robin") as! SKSpriteNode
            Img.name = "Alex"
            Img.texture = SKTexture(imageNamed: "Layer1_alexander7")
            
            
        case 7:
            self.Goblin = SKSpriteNode(imageNamed: "Layer1_goblin_1")
            self.Goblin.position = CGPoint(x: Plays.position.x-100, y: -39.5)
            self.Goblin.name = "Goblin"
            self.Goblin.size = CGSize(width: 80, height: 80)
            self.Goblin.run((SKAction.scaleX(to: -1, duration: 0.1)))
            scene?.addChild(Goblin)
            
            nomeD.removeFromParent()
            dialogo.removeFromParent()
            testa.removeFromParent()
            BarraOnOff(Vedere: false)
            Cam.run(SKAction.moveBy(x: -600, y: 0, duration: 3))
            Movimento(Name:"Isaac",X: -500,Y: 0,Forever: false,Animation: "LowToneC",velocita: 3)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [self] in
                BarraOnOff(Vedere: true)
                Dialogo(testo : "Isaac! Where did you go?! \nAre you gonna help?!",Name : "Alex")
            }
        case 8:
            Dialogo(testo : "Or are you gonna be a deadweight?! \nMove on!",Name : "Alex")
        case 9:
            player.texture = SKTexture(imageNamed: "IsaacG")
            Dialogo(testo : "Deadwight...me? I couldn't even protect my friend \nwithout getting my hands dirty...",Name : "Isaac")
        case 10:
            Dialogo(testo : "Did that goblin deserve it? But now Robin fears me... \n And Alex is mocking me...",Name : "Isaac")
        case 11:
            Dialogo(testo: "What do I have to do?", Name : "Isaac")
        case 12:
            let transition: SKTransition = SKTransition.fade(withDuration: 1.3)
            let Fine = SKScene(fileNamed: "Fine")
            Fine?.scaleMode = .aspectFit
           view?.presentScene(Fine!,transition: transition)
            
        default:
            break
        }

}
    
    
   //funzioni simili a quelle di inizio
    
    
    override func update(_ currentTime: CFTimeInterval)
    {
        // cosi la finestra di dialogo stara sempre nella stessa posizione
        //usando la posizione iniziale - posizione finale
        pos.position = CGPoint(x: (posizioneCam.position.x)-Cam.position.x, y: 0)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        if (CouterB){
        if((node.name == "barraS")||(node.name == "barraD")||(node.name == "barraC")||(node.name == "testo")){
        caunter = caunter + 1
        Azioni(Counter: caunter)
        }
        }
}
    
    
    
    func Movimento(Name:String,X: Double,Y: Double,Forever: Bool,Animation: String,velocita: Double) {
        let Img = childNode(withName: Name) as! SKSpriteNode
        let move = SKAction.moveBy(x: X, y: Y, duration: velocita)
        
        if Animation == ""{
            if(Forever){
                Img.run(SKAction.repeatForever(move))
            }else{
                Img.run(move)
            }
            //movimento + animazione gestita dal myaction
        }else{
            let actionFelix = SKAction(named: Animation)!
            if(Forever){
                Img.run(SKAction.repeatForever(actionFelix))
                Img.run(SKAction.repeatForever(move))
                
            }else{
                Img.run(actionFelix)
                Img.run(move)
            }
    }
         
}
    
    
    func AnimationoOnly(Name: String,numeroS: Int,X: Double,Y: Double,L: Double,H: Double,Forever: Bool) {
        var Img = SKSpriteNode()
        Img = SKSpriteNode(imageNamed: Name)
        Img.name=Name
        Img.size = CGSize(width: L, height: H)
        Img.position = CGPoint( x :  X , y : Y)
        scene?.addChild(Img)
        
        if numeroS  > 1 {
        var textureArray = [SKTexture]()
        let range = 1...numeroS
        for index in range{
            let textureName = Name+String(index)
            let texture = SKTexture(imageNamed: textureName)
            textureArray.append(texture)
        }
            let runAction = SKAction.animate(with: textureArray , timePerFrame: 0.5)
            if(Forever){
                Img.run(SKAction.repeatForever(runAction))
            }else{
                Img.run(runAction)
            }

        }
    }
    
    
    func BarraOnOff(Vedere: Bool){
        if (Vedere){
            barra[0].position = CGPoint(x: (-310)-pos.position.x, y: -128)
         barra[0].size = CGSize(width: 127, height: 96)
        barra[0].name="barraS"
        scene?.addChild(barra[0])
        
            barra[1].position = CGPoint(x: 20-pos.position.x, y: -128)
         barra[1].size = CGSize(width: 535, height: 96)
           
        barra[1].name="barraC"
        scene?.addChild(barra[1])
        
            barra[2].position = CGPoint(x: 351-pos.position.x, y: -128)
         barra[2].size = CGSize(width: 127, height: 96)
 
        barra[2].name="barraD"
        scene?.addChild(barra[2])
        }else{
            barra[0].removeFromParent()
            barra[1].removeFromParent()
            barra[2].removeFromParent()
        }
    }
    
    
    
    func Dialogo(testo : String,Name : String){
        //nome nella barra a sinistra
        //rimuovo il precedente
        nomeD.removeFromParent()
        //metto il nuovo
        nomeD.text = Name
        nomeD.fontSize = 10
        nomeD.horizontalAlignmentMode = .left
        if Name == "Alex"{
            nomeD.fontColor = SKColor.red
        }else if Name == "Robin"{
            nomeD.fontColor = SKColor.blue
        }else if Name == "Isaac"{
            nomeD.fontColor = SKColor.green
        }
        nomeD.position = CGPoint(x: -355-pos.position.x, y: -92)
        addChild(nomeD)
        
        //metto la testa del personaggio corrente
        //rimuovo la vecchia
        testa.removeFromParent()
        //metto la corrente
        testa  = SKSpriteNode(imageNamed: Name)
        testa.position = CGPoint(x: -292-pos.position.x, y: -158)
        testa.size = CGSize (width: 93, height: 97)
        addChild(testa)
        
        //dialogo
        //tolgo il precedente
        dialogo.removeFromParent()
        dialogo.name = "testo"
        //metto il nuovo
        dialogo.text = testo
        dialogo.lineBreakMode = .byWordWrapping
        dialogo.numberOfLines = 2
        dialogo.fontSize = 20
        dialogo.horizontalAlignmentMode = .left
        dialogo.fontColor = SKColor.white
        dialogo.position = CGPoint(x: -246-pos.position.x, y: -150)
        addChild(dialogo)
        
    }
    func Suono (Nome: String,RimuoviVecchia: Bool,Stop: Bool){
        if Nome == "" {
        if Stop{
            sound.run(SKAction.stop())
        }else{
            sound.run(SKAction.play())
            
        }
        }else if(RimuoviVecchia){
           sound.removeFromParent()
            sound = SKAudioNode(fileNamed: Nome)
            scene?.addChild(self.sound)
        }else{
            sound = SKAudioNode(fileNamed: Nome)
            scene?.addChild(self.sound)
        }
    
    }

}
