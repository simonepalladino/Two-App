

import Foundation
import SpriteKit
class RaccontoSpada: SKScene {
    override func didMove(to view: SKView) {
        
        let dialogo = SKLabelNode(fontNamed: "Chalkduster")
        //metto il nuovo
        dialogo.text = "Robin and Alexander run towards the village \n while Isaac stays back for his slowness, \nlosing sight of them."
        dialogo.lineBreakMode = .byWordWrapping
        dialogo.numberOfLines = 2
        dialogo.fontSize = 20
        dialogo.horizontalAlignmentMode = .center
        dialogo.fontColor = SKColor.white
        dialogo.position = CGPoint(x: frame.midX, y: frame.midY-20)
        addChild(dialogo)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        let transition: SKTransition = SKTransition.flipHorizontal(withDuration: 0.5)
        let Spada = SKScene(fileNamed: "Spada")
       Spada?.scaleMode = .aspectFit
       self.view?.presentScene(Spada!,transition: transition)
        
}
}
