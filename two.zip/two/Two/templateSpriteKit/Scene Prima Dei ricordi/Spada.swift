//
//  Spada.swift
//  templateSpriteKit
//
//  Created by Vincenzo Bastelli on 15/04/22.
//

import Foundation
import SpriteKit
class Spada: SKScene {
    var Goblin = SKSpriteNode()
    var textureArray = SKTexture()
    var sound = SKAudioNode()
    let dialogo = SKLabelNode(fontNamed: "Chalkduster")
    var testa  = SKSpriteNode()
    var nomeD = SKLabelNode(fontNamed: "Chalkduster")
    var barra : [SKSpriteNode] = [SKSpriteNode(imageNamed: "Layer2_dw1"),SKSpriteNode(imageNamed: "Layer2_dw2"),SKSpriteNode(imageNamed: "Layer2_dw3")]
    var caunter = 0
    var CouterB = true
    var player = SKSpriteNode()
    var Cam = SKCameraNode()
    let posizioneCam = SKCameraNode()
    var pos = SKSpriteNode()
    
    override func didMove(to view: SKView) {
        Suono (Nome: "Dopo il boom",RimuoviVecchia: true,Stop: false)
        Cam = childNode(withName: "cameraP") as! SKCameraNode
        //per prendere il valore della posizione iniziale della camera
        posizioneCam.position.x = Cam.position.x
        
        AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: 170,Y: 53,L: 256,H: 256,Forever: true)
        AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: -400,Y: 51,L: 256,H: 256,Forever: true)
      
        Movimento(Name:"Isaac",X: -513,Y: 0,Forever: false,Animation: "protC",velocita: 4)
        
        player = childNode(withName: "Isaac") as! SKSpriteNode
        player.run(SKAction.scaleX(to: -1, duration: 0.1))
        
        Goblin = childNode(withName: "GoblinS") as! SKSpriteNode
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [self] in
            self.Goblin.run(SKAction(named: "GoblinC")!)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [self] in
            Suono (Nome: "goblin",RimuoviVecchia: true,Stop: false)
            Goblin.run(SKAction.moveBy(x: -200, y: 0, duration: 0.5))
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [self] in
            Suono (Nome: "paura",RimuoviVecchia: true,Stop: false)
            player.run(SKAction.scaleX(to: 1, duration: 0.1))
            self.BarraOnOff(Vedere: true)
            Dialogo(testo : "A Sword!",Name : "Isaac")
        }
        
  
    }
    
    //azioni parte importante delle scene 
    func Azioni (Counter: Int){
        switch caunter {
        case 1:
            let Cavaliere = childNode(withName: "cavaliere") as! SKSpriteNode
            Cavaliere.texture = SKTexture(imageNamed: "Layer1_knight2")
                player.texture = SKTexture(imageNamed: "Layer1_prot13")
                Dialogo(testo : "It's too heavy...",Name : "Isaac")
            
        case 2:
            Dialogo(testo : "I have no choice! I have to run!",Name : "Isaac")
        case 3:
            BarraOnOff(Vedere: false)
            nomeD.removeFromParent()
            dialogo.removeFromParent()
            testa.removeFromParent()
            player.run(SKAction.scaleX(to: -1, duration: 0.1))
            Movimento(Name:"GoblinS",X: -150,Y: 0,Forever: false,Animation: "GoblinC",velocita: 4)
            Movimento(Name:"Isaac",X: -500,Y: 0,Forever: false,Animation: "LowToneC",velocita: 4)
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [self] in
                self.Goblin = SKSpriteNode(imageNamed: "Layer1_goblin_1")
                self.Goblin.position = CGPoint(x: -420-pos.position.x, y: -39.5)
                self.Goblin.name = "Goblin"
                self.Goblin.size = CGSize(width: 80, height: 80)
                self.Goblin.run((SKAction.scaleX(to: -1, duration: 0.1)))
                scene?.addChild(Goblin)
                Movimento(Name:"Goblin",X: 200,Y: 0,Forever: false,Animation: "GoblinC",velocita: 2.5)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [self] in
                self.Suono (Nome: "goblin",RimuoviVecchia: false,Stop: false)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 6) { [self] in
            self.Suono (Nome: "",RimuoviVecchia: false,Stop: true)
                BarraOnOff(Vedere: true)
                Dialogo(testo : "HELP!!!",Name : "Isaac")
            }
        case 4:
            Movimento(Name:"Isaac",X: -100,Y: 0,Forever: false,Animation: "LowToneC",velocita: 0.7)
            Movimento(Name:"Goblin",X: 100,Y: 0,Forever: false,Animation: "GoblinC",velocita: 0.7)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                let transition: SKTransition = SKTransition.fade(withDuration: 1.3)
                let Gameplay = SKScene(fileNamed: "Gameplay")
                Gameplay?.scaleMode = .aspectFit
               view?.presentScene(Gameplay!,transition: transition)
            }
        default:
            break
        }

}
    
    
   //funzioni simili a quelle di inizio
    
    
    override func update(_ currentTime: CFTimeInterval)
    {
        // la camera inseguira il personaggio dopo un azione
        if caunter == 3{
        Cam.position.x = player.position.x
        }
        // cosi la finestra di dialogo stara sempre nella stessa posizione
        //usando la posizione iniziale - posizione finale 
        pos.position = CGPoint(x: (posizioneCam.position.x)-Cam.position.x, y: 0)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        if (CouterB){
        if((node.name == "barraS")||(node.name == "barraD")||(node.name == "barraC")||(node.name == "testo")){
        caunter = caunter + 1
        Azioni(Counter: caunter)
        }
        }
}
    
    
    
    func Movimento(Name:String,X: Double,Y: Double,Forever: Bool,Animation: String,velocita: Double) {
        let Img = childNode(withName: Name) as! SKSpriteNode
        let move = SKAction.moveBy(x: X, y: Y, duration: velocita)
        
        if Animation == ""{
            if(Forever){
                Img.run(SKAction.repeatForever(move))
            }else{
                Img.run(move)
            }
            //movimento + animazione gestita dal myaction
        }else{
            let actionFelix = SKAction(named: Animation)!
            if(Forever){
                Img.run(SKAction.repeatForever(actionFelix))
                Img.run(SKAction.repeatForever(move))
                
            }else{
                Img.run(actionFelix)
                Img.run(move)
            }
    }
         
}
    
    
    func AnimationoOnly(Name: String,numeroS: Int,X: Double,Y: Double,L: Double,H: Double,Forever: Bool) {
        var Img = SKSpriteNode()
        Img = SKSpriteNode(imageNamed: Name)
        Img.name=Name
        Img.size = CGSize(width: L, height: H)
        Img.position = CGPoint( x :  X , y : Y)
        scene?.addChild(Img)
        
        if numeroS  > 1 {
        var textureArray = [SKTexture]()
        let range = 1...numeroS
        for index in range{
            let textureName = Name+String(index)
            let texture = SKTexture(imageNamed: textureName)
            textureArray.append(texture)
        }
            let runAction = SKAction.animate(with: textureArray , timePerFrame: 0.5)
            if(Forever){
                Img.run(SKAction.repeatForever(runAction))
            }else{
                Img.run(runAction)
            }

        }
    }
    
    
    func BarraOnOff(Vedere: Bool){
        if (Vedere){
            barra[0].position = CGPoint(x: (-310)-pos.position.x, y: -128)
         barra[0].size = CGSize(width: 127, height: 96)
        barra[0].name="barraS"
        scene?.addChild(barra[0])
        
            barra[1].position = CGPoint(x: 20-pos.position.x, y: -128)
         barra[1].size = CGSize(width: 535, height: 96)
           
        barra[1].name="barraC"
        scene?.addChild(barra[1])
        
            barra[2].position = CGPoint(x: 351-pos.position.x, y: -128)
         barra[2].size = CGSize(width: 127, height: 96)
 
        barra[2].name="barraD"
        scene?.addChild(barra[2])
        }else{
            barra[0].removeFromParent()
            barra[1].removeFromParent()
            barra[2].removeFromParent()
        }
    }
    
    
    
    func Dialogo(testo : String,Name : String){
        //nome nella barra a sinistra
        //rimuovo il precedente
        nomeD.removeFromParent()
        //metto il nuovo
        nomeD.text = Name
        nomeD.fontSize = 10
        nomeD.horizontalAlignmentMode = .left
        if Name == "Alex"{
            nomeD.fontColor = SKColor.red
        }else if Name == "Robin"{
            nomeD.fontColor = SKColor.blue
        }else if Name == "Isaac"{
            nomeD.fontColor = SKColor.green
        }
        nomeD.position = CGPoint(x: -355-pos.position.x, y: -92)
        addChild(nomeD)
        
        //metto la testa del personaggio corrente
        //rimuovo la vecchia
        testa.removeFromParent()
        //metto la corrente
        testa  = SKSpriteNode(imageNamed: Name)
        testa.position = CGPoint(x: -292-pos.position.x, y: -158)
        testa.size = CGSize (width: 93, height: 97)
        addChild(testa)
        
        //dialogo
        //tolgo il precedente
        dialogo.removeFromParent()
        dialogo.name = "testo"
        //metto il nuovo
        dialogo.text = testo
        dialogo.lineBreakMode = .byWordWrapping
        dialogo.numberOfLines = 2
        dialogo.fontSize = 20
        dialogo.horizontalAlignmentMode = .left
        dialogo.fontColor = SKColor.white
        dialogo.position = CGPoint(x: -246-pos.position.x, y: -150)
        addChild(dialogo)
        
    }
    func Suono (Nome: String,RimuoviVecchia: Bool,Stop: Bool){
        if Nome == "" {
        if Stop{
            sound.run(SKAction.stop())
        }else{
            sound.run(SKAction.play())
            
        }
        }else if(RimuoviVecchia){
           sound.removeFromParent()
            sound = SKAudioNode(fileNamed: Nome)
            scene?.addChild(self.sound)
        }else{
            sound = SKAudioNode(fileNamed: Nome)
            scene?.addChild(self.sound)
        }
    
    }

}
