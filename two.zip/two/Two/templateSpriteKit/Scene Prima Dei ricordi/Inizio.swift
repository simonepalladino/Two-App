//
//  Scena2.swift
//  templateSpriteKit
//
//  Created by Vincenzo Bastelli on 11/04/22.
//

import Foundation
import SpriteKit
import SwiftUI

class Inizio: SKScene {
    var sound = SKAudioNode()
    let dialogo = SKLabelNode(fontNamed: "Chalkduster")
    var testa  = SKSpriteNode()
    var nomeD = SKLabelNode(fontNamed: "Chalkduster")
    var barra : [SKSpriteNode] = [SKSpriteNode(imageNamed: "Layer2_dw1"),SKSpriteNode(imageNamed: "Layer2_dw2"),SKSpriteNode(imageNamed: "Layer2_dw3")]
    var Bcauntr = false
    var caunter = 0
    var p = SKSpriteNode()
    var Cam = SKSpriteNode()
    var pos = SKSpriteNode()
    var play = SKSpriteNode()
    var felix = SKSpriteNode()
    override func didMove(to view: SKView) {
        //suono
         sound = SKAudioNode(fileNamed: "Inizio")
        scene?.addChild(sound)

        //nome per far in modo che la funzione tasto riconosce anche la barra dei testi
        dialogo.name = "testo"
        //camera
        Cam = childNode(withName: "camera") as! SKSpriteNode
        Cam.run(SKAction.moveBy(x: 0, y: -351.4, duration: 2))
        
        //albero
        AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: -249.999,Y: 53,L: 256,H: 256,Forever: true)
        AnimationoOnly(Name: "Layer 1_albero",numeroS: 4,X: 170,Y: 53,L: 256,H: 256,Forever: true)
           
   

    

        //vedere perche non si ri upload
            
           Movimento(Name:"alex",X: 320,Y: 0,Forever: false,numeroS: 1,Animation: "alexC")
            Movimento(Name:"robin",X: 353,Y: 0,Forever: false,numeroS: 1,Animation: "robinC")
            play = childNode(withName: "prot") as! SKSpriteNode
            play.run(SKAction.scaleX(to: -2, duration: 0.1))

        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.BarraOnOff(Vedere: true)
            self.Dialogo(testo : "This wood is so huge, but we know it well",Name :"Isaac")
         }

    


        

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        if((node.name == "barraS")||(node.name == "barraD")||(node.name == "barraC")||(node.name == "testo")){
            caunter = caunter + 1
            Bcauntr = true
            Azioni(Counter: caunter, CounterB: Bcauntr)
        }
        


    }

    
    func AnimationoOnly(Name: String,numeroS: Int,X: Double,Y: Double,L: Double,H: Double,Forever: Bool) {
        var Img = SKSpriteNode()
        Img = SKSpriteNode(imageNamed: Name)
        Img.name=Name
        Img.size = CGSize(width: L, height: H)
        Img.position = CGPoint( x :  X , y : Y)
        scene?.addChild(Img)
        
        if numeroS  > 1 {
        var textureArray = [SKTexture]()
        let range = 1...numeroS
        for index in range{
            let textureName = Name+String(index)
            let texture = SKTexture(imageNamed: textureName)
            textureArray.append(texture)
        }
            let runAction = SKAction.animate(with: textureArray , timePerFrame: 0.5)
            if(Forever){
                Img.run(SKAction.repeatForever(runAction))
            }else{
                Img.run(runAction)
            }

        }
    }
    
    func Movimento(Name:String,X: Double,Y: Double,Forever: Bool,numeroS: Int,Animation: String) {
        let Img = childNode(withName: Name) as! SKSpriteNode
        let move = SKAction.moveBy(x: X, y: Y, duration: 4)
        
        if Animation == ""{
            if(Forever){
                Img.run(SKAction.repeatForever(move))
            }else{
                Img.run(move)
            }
            //movimento + animazione gestita dal myaction
        }else{
            let actionFelix = SKAction(named: Animation)!
            if(Forever){
                Img.run(SKAction.repeatForever(actionFelix))
                Img.run(SKAction.repeatForever(move))
                
            }else{
                Img.run(actionFelix)
                Img.run(move)
            }
    }
         
}
    func BarraOnOff(Vedere: Bool){
        if (Vedere){
         barra[0].position = CGPoint(x: -310, y: -128)
        // barra[0].position = p.position
         barra[0].size = CGSize(width: 127, height: 96)
        barra[0].name="barraS"
        scene?.addChild(barra[0])
         barra[1].position = CGPoint(x: 20, y: -128)
         barra[1].size = CGSize(width: 535, height: 96)
        barra[1].name="barraC"
        scene?.addChild(barra[1])
         barra[2].position = CGPoint(x: 351, y: -128)
         barra[2].size = CGSize(width: 127, height: 96)
        barra[2].name="barraD"
        scene?.addChild(barra[2])
        }else{
            barra[0].removeFromParent()
            barra[1].removeFromParent()
            barra[2].removeFromParent()
        }
    }
    func Dialogo(testo : String,Name : String){
        //nome nella barra a sinistra
        //rimuovo il precedente
        nomeD.removeFromParent()
        //metto il nuovo
        nomeD.text = Name
        nomeD.fontSize = 10
        nomeD.horizontalAlignmentMode = .left
        if Name == "Alex"{
            nomeD.fontColor = SKColor.red
        }else if Name == "Robin"{
            nomeD.fontColor = SKColor.blue
        }else if Name == "Isaac"{
            nomeD.fontColor = SKColor.green
        }
        nomeD.position = CGPoint(x: -355, y: -92)
        addChild(nomeD)
        
        //metto la testa del personaggio corrente
        //rimuovo la vecchia
        testa.removeFromParent()
        //metto la corrente
        testa  = SKSpriteNode(imageNamed: Name)
        testa.position = CGPoint(x: -292, y: -158)
        testa.size = CGSize (width: 93, height: 97)
        addChild(testa)
        
        //dialogo
        //tolgo il precedente
        dialogo.removeFromParent()
        //metto il nuovo
        dialogo.text = testo
        dialogo.lineBreakMode = .byWordWrapping
        dialogo.numberOfLines = 2
        dialogo.fontSize = 20
        dialogo.horizontalAlignmentMode = .left
        dialogo.fontColor = SKColor.white
        dialogo.position = CGPoint(x: -246, y: -150)
        addChild(dialogo)
        
    }
    func Azioni (Counter: Int,CounterB: Bool){
        switch caunter {
        case 1:
            Dialogo(testo : "Be careful, It's still full of dangers...",Name :"Robin")
        case 2:
            Dialogo(testo : "Maybe it's dangerous for you, \n I could return to the village with closed eyes!",Name :"Alex")
        case 3:
           // if CounterB == true {
                testa.removeFromParent()
                dialogo.removeFromParent()
                nomeD.removeFromParent()
                BarraOnOff(Vedere: false)
                Bcauntr = false
                 sound.removeFromParent()
                sound = SKAudioNode(fileNamed: "Boom")
               scene?.addChild(sound)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.7) { [self] in
                    self.sound.removeFromParent()
                    self.BarraOnOff(Vedere: true)
                    self.sound = SKAudioNode(fileNamed: "Dopo il boom")
                    self.scene?.addChild(self.sound)
                    self.Dialogo(testo : "What was that!? ",Name :"Robin")
                 }
            //}
        case 4:
            self.Dialogo(testo : "Let's find out!",Name :"Alex")
        case 5:
            self.BarraOnOff(Vedere: false)
            testa.removeFromParent()
            dialogo.removeFromParent()
            nomeD.removeFromParent()
            Movimento(Name:"alex",X: -320,Y: 0,Forever: false,numeroS: 1,Animation: "alexC")
            var Img = childNode(withName: "alex") as! SKSpriteNode
            Img.run(SKAction.scaleX(to: -3, duration: 0.1))
            Movimento(Name:"robin",X: -353,Y: 0,Forever: false,numeroS: 1,Animation: "robinC")
            Img = childNode(withName: "robin") as! SKSpriteNode
            Img.run(SKAction.scaleX(to: -1.3, duration: 0.1))
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { [self] in
                let transition: SKTransition = SKTransition.flipHorizontal(withDuration: 0.5)
                let Racconto = SKScene(fileNamed: "RaccontoSpada")
               Racconto?.scaleMode = .aspectFit
               self.view?.presentScene(Racconto!,transition: transition)
            }
        default:
            break
        }

}
}
