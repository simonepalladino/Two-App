
import SpriteKit

class Menu: SKScene {
    var sound = SKAudioNode(fileNamed: "backMusic")
    var schermo = SKSpriteNode()
    var play = SKSpriteNode()
    var Tsound = SKSpriteNode()
    var OnOff = true
    override func didMove(to view: SKView) {
        //suono
        scene?.addChild(sound)
        
        //schermo
        SchermoTasto(Nome: "Schermo1",X: -203 ,Y: 112)
        SchermoTasto(Nome: "Schermo2",X: 203 ,Y: 112)
        
        //tasto suono
        TastoVolume(Nome: "Layer 1_Tsuono1")
        
        //tasto play
        PlayTasto(Nome: "Layer 1_Play1",X: 0.5 , Y: 0.2,L: 200,H: 200)
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
      //  var play1 = scene?.childNode(withName: "play") as! SKSpriteNode
        if (node.name == "Layer 1_Play1") {
            EliminaScena(Nome: "Layer 1_Play1")
            PlayTasto(Nome: "Layer 1_Play2",X: 0.5 , Y: 0.2,L: 200,H: 200)
            
            //tasto suono che toglie la musica
        }else if(node.name == "Tsound"){
            if OnOff == true {
                TastoVolume(Nome: "Layer 1_Tsuono2")
               sound.run(SKAction.stop())
                OnOff = false
                
            }else if OnOff == false {
                TastoVolume(Nome: "Layer 1_Tsuono1")
                sound.run(SKAction.play())
                OnOff = true
            }
            
            //animazione tasti
        }else if (node.name == "Layer 1_Newgame1"){
            EliminaScena(Nome: "Layer 1_Newgame1")
            PlayTasto(Nome: "Layer 1_Newgame2",X: 0,Y: 60,L: 200,H: 200)
            
        }else if (node.name == "Layer 1_Exit1"){
            EliminaScena(Nome: "Layer 1_Exit1")
            PlayTasto(Nome: "Layer 1_Exit2",X: 0,Y: -20,L: 200,H: 200)
        }
        /*else if (node.name == "Layer 1_Continue1"){
            EliminaScena(Nome: "Layer 1_Continue1")
            PlayTasto(Nome: "Layer 1_Continue2",X: 0,Y: 140,L: 200,H: 200)
            
        }*/
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        //azione dei 4 tasti sul menu
    if (node.name == "Layer 1_Exit2") {
        EliminaScena(Nome: "Layer 1_Continue1")
        EliminaScena(Nome: "Layer 1_Exit2")
        EliminaScena(Nome: "Layer 1_Newgame1")
        PlayTasto(Nome: "Layer 1_Play1",X: 0.5 , Y: 0.2,L: 200,H: 200)
    }else if (node.name == "Layer 1_Play2"){
        let move = SKAction.moveBy(x: -456, y: 0, duration: 1)
        EliminaScena(Nome: "Layer 1_Play2")
        PlayTasto(Nome: "Layer 1_Continue1",X: 456,Y: 140,L: 200,H: 200)
        play.run(move)
        PlayTasto(Nome: "Layer 1_Newgame1",X: 456,Y: 60,L: 200,H: 200)
        play.run(move)
        PlayTasto(Nome: "Layer 1_Exit1",X: 456,Y: -20,L: 200,H: 200)
        play.run(move)
    }else if (node.name == "Layer 1_Newgame2"){
        sound.run(SKAction.stop())
        sound.removeFromParent()
        let transition: SKTransition = SKTransition.flipHorizontal(withDuration: 0.5)
         let Introduzione = SKScene(fileNamed: "Introduzione")
        Introduzione?.scaleMode = .aspectFit
        self.view?.presentScene(Introduzione!,transition: transition)

    }
}
    
    func TastoVolume(Nome: String){
        Tsound = SKSpriteNode(imageNamed: Nome)
        Tsound.size = CGSize(width: 50, height: 50)
        Tsound.position = CGPoint( x : -364 , y : -28)
        Tsound.name="Tsound"
        scene?.addChild(Tsound)
    }
    func SchermoTasto(Nome: String,X: Double,Y: Double){
        schermo = SKSpriteNode(imageNamed: Nome)
        schermo.size = CGSize(width: 406, height: 376)
        schermo.position = CGPoint( x :  X , y : Y)
        scene?.addChild(schermo)
    }
    func PlayTasto(Nome: String,X: Double,Y: Double,L: Double,H: Double){
        play = SKSpriteNode(imageNamed: Nome)
        play.name=Nome
        play.size = CGSize(width: L, height: H)
        play.position = CGPoint( x :  X , y : Y)
        scene?.addChild(play)
    }
    func EliminaScena(Nome: String) {
        let play1 = scene?.childNode(withName: Nome) as! SKSpriteNode
        play1.removeFromParent()
    }


}

