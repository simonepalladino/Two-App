//
//  Introduzione.swift
//  prova55
//
//  Created by Stefano Leva on 15/04/22.
//

import Foundation
import SpriteKit

class Introduzione: SKScene {
    
    var counter=0
    let text = SKLabelNode(fontNamed: "Chalkduster")
    
    
    override func didMove(to view: SKView) {
        text.name = "testo"
        Dialogo(testo: "Centuries ago, humans and goblins fought. \nTheir war only caused innocent victims and bloodshed \nand no one came up victorious.")
    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            let touch = touches.first
            let touchLocation = touch!.location(in: self)
            let node = self.atPoint(touchLocation)
            if((node.name == "background")||(node.name == "testo")){
                counter = counter + 1
                Azioni(Counter: counter)
            }

        }
    
    func Azioni(Counter: Int){
        switch Counter{
           
            case 1:
                Dialogo(testo:"Still now, poor villages try to resist the numerous attack \nof the goblins. But somewhere, there was a little village \ngoblins never attacked yet.")
            
            case 2:
                Dialogo(testo: "There lived three young men:")
            
            case 3:
                Dialogo(testo:"The red-haired Alexander, \nthe personification of strenght and impulsiveness, \nborn as a warrior and living as a warrior.")
            
            case 4:
                Dialogo(testo:"The timorous Robin, \nthe personification of caution and innocence, \nalways watching his back and the others.")
            
            case 5:
                Dialogo(testo:"And then there was Isaac, \na poor boy in a poor family that never gave him \nthe attentions he needed.")
            
            case 6:
                Dialogo(testo:"One day, the three of them went in the neighbour woods \nwhen something happened...")
        case 7:
            let transition: SKTransition = SKTransition.flipHorizontal(withDuration: 0.5)
            let Inizio = SKScene(fileNamed: "Inizio")
           Inizio?.scaleMode = .aspectFit
           self.view?.presentScene(Inizio!,transition: transition)
            default: break
        }
    }
    
//    text.text = "Centuries ago, humans and goblins fought. \nTheir war only caused innocent victims and bloodshed and no one came up victorious. \nStill now, poor villages try to resist the numerous attack of the goblins. \n\nBut somewhere, there was a little village goblins never attacked yet. \nThere lived three young men: \nThe red-haired Alexander, the personification of strenght and impulsiveness, born as a warrior and living as a warrior. \nThe timorous Robin, the personification of caution and innocence, always watching his back and the others. \nAnd then there was Isaac, a poor boy in a poor family who never gave him the attentions he needed.\n\nOne day, the three of them went in the neighbour woods when something happened..."
    
    func Dialogo(testo : String){
            //dialogo
            //tolgo il precedente
            text.removeFromParent()
            //metto il nuovo
            text.text = testo
            text.lineBreakMode = .byWordWrapping
            text.numberOfLines = 2
            text.fontSize = 20
            text.horizontalAlignmentMode = .center
            text.fontColor = SKColor.white
            text.position = CGPoint(x: 0, y: 0)
            addChild(text)

        }

}
