//
//  GameScene.swift
//  templateSpriteKit
//
//  Created by Lorenzo di Palo on 07/04/22.
//

import SpriteKit

class gameplay: SKScene {
    
    override func didMove(to view: SKView) {
     //   let backgroundMusic = SKAudioNode(fileNamed: "backMusic")
     //   backgroundMusic.autoplayLooped = true
        backgroundColor = SKColor.blue
        let relativeName="Layer1_sprite_"
        let hero = SKSpriteNode(imageNamed: relativeName+"1")
        let backgroundCloud = SKSpriteNode(imageNamed: "Layer1_cloud_1")
        let backgroundTree = SKSpriteNode(imageNamed: "Layer1_tree_1")
        //let backgroundAnimated = SKSpriteNode(imageNamed: "Layer1_cloud_1")
        //il nome serve ad importare hero nelle altre function
        hero.name = "hero"
        hero.position = CGPoint(x: -300 , y:100)
        hero.size = CGSize(width: 75,height: 75)
        backgroundCloud.position = CGPoint(x: 300 , y: 300)
        backgroundCloud.size = CGSize(width: 50,height: 50)
        backgroundTree.position = CGPoint(x: -100 , y: 150)
        backgroundTree.size = CGSize(width: 90,height: 120)
        var heroTextureArray = [SKTexture]()
        var backgroundCloudTextureArray = [SKTexture]()
        var backgroundTreeTextureArray = [SKTexture]()
        for index in 1...2{
            let textureName = "Layer1_cloud_"+String(index)
            let texture = SKTexture(imageNamed: textureName)
            backgroundCloudTextureArray.append(texture)
        }
        for index in 1...4{
            let textureName = "Layer1_tree_"+String(index)
            let texture = SKTexture(imageNamed: textureName)
            backgroundTreeTextureArray.append(texture)
        }
        
        //range da cambiare in caso si vogliano inserire-rimuovere
        // alcuni frame
        //i frame 6-15 sono quelli che contengono la camminat del personaggio
        // quindi scartando quelli con la fionda riesco ad estrarli
        let range = 6...15
        for index in range{
            if(index<11 || index>13){
                let textureName = relativeName+String(index)
                let texture = SKTexture(imageNamed: textureName)
                heroTextureArray.append(texture)
            }
            
        }
        let backgroundCloudAnimateAction = SKAction.animate(with: backgroundCloudTextureArray, timePerFrame: 0.6)
        let backgroundTreeAnimateAction = SKAction.animate(with: backgroundTreeTextureArray, timePerFrame: 0.2)
        backgroundCloud.run(SKAction.repeatForever(backgroundCloudAnimateAction))
        backgroundTree.run(SKAction.repeatForever(backgroundTreeAnimateAction))
        let heroRunAction = SKAction.animate(with: heroTextureArray , timePerFrame: 0.1)
        hero.run(SKAction.repeatForever(heroRunAction))
     //   scene?.addChild(backgroundMusic)
        scene?.addChild(backgroundCloud)
        scene?.addChild(backgroundTree)
        scene?.addChild(hero)
        
        
        /// tasti jump dx sx
        let jmpBtn = SKSpriteNode.init(imageNamed: "Layer1_jump_btn1")
        jmpBtn.name = "jmp1"
        jmpBtn.size = CGSize(width: 150,height: 150)
        jmpBtn.position = CGPoint(x: 150 , y: 100)
        let rightBtn = SKSpriteNode.init(imageNamed: "Layer1_right_btn1")
        rightBtn.name = "right1"
        rightBtn.size = CGSize(width: 150,height: 150)
        rightBtn.position = CGPoint(x: 200 , y: 25)
        let leftBtn = SKSpriteNode.init(imageNamed: "Layer1_left_btn1")
        leftBtn.name = "left1"
        leftBtn.size = CGSize(width: 150,height: 150    )
        leftBtn.position = CGPoint(x: 100 , y: 25)
        scene?.addChild(jmpBtn)
        scene?.addChild(leftBtn)
        scene?.addChild(rightBtn)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        let heroS = scene?.childNode(withName: "hero")
        if (node.name == "jmp1") {
            let sound = SKAction.playSoundFileNamed("salto", waitForCompletion: false)
            let move = SKAction.moveBy(x: 0, y: 100, duration: 0.5)
            let moveSequence = SKAction.sequence([sound,move,move.reversed()])
            heroS?.run(SKAction.repeat(moveSequence,count: 1))
            // forzo il tipo SKSpriteNode così la variabile otterrà il metodo .texture
            // cpoia incolla per gli altri 2 if
            let jmpBtnPar = scene?.childNode(withName: "jmp1") as! SKSpriteNode
            let jmpText2 = SKTexture(imageNamed: "Layer1_jump_btn2")
            jmpBtnPar.texture=jmpText2
        }
        else if (node.name == "left1") {
            let sound = SKAction.playSoundFileNamed("passi", waitForCompletion: false)
            let move = SKAction.moveBy(x: -50, y: 0, duration: 0.5)
            let mirror = SKAction.scaleX(to: -1.0, duration: 0.1)
            let moveSequence = SKAction.sequence([mirror,sound,move])
            heroS?.run(SKAction.repeat(moveSequence,count: 1))
            let leftBtnPar = scene?.childNode(withName: "left1") as! SKSpriteNode
            let leftText2 = SKTexture(imageNamed: "Layer1_left_btn2")
            leftBtnPar.texture=leftText2
        }
        else if (node.name == "right1") {
            let sound = SKAction.playSoundFileNamed("passi", waitForCompletion: false)
            let move = SKAction.moveBy(x: 50, y: 0, duration: 0.5)
            let mirror = SKAction.scaleX(to: 1.0, duration: 0.1)
            let moveSequence = SKAction.sequence([mirror,sound,move])
            heroS?.run(SKAction.repeat(moveSequence,count: 1))
            let rightBtnPar = scene?.childNode(withName: "right1") as! SKSpriteNode
            let rightText2 = SKTexture(imageNamed: "Layer1_right_btn2")
            rightBtnPar.texture=rightText2
        }
        
        //        rendere il touch began, touch hold
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let jmpBtnPar = scene?.childNode(withName: "jmp1") as! SKSpriteNode
        let jmpText1 = SKTexture(imageNamed: "Layer1_jump_btn1")
            jmpBtnPar.texture=jmpText1
        
        
        let leftBtnPar = scene?.childNode(withName: "left1") as! SKSpriteNode
        let leftText2 = SKTexture(imageNamed: "Layer1_left_btn1")
        leftBtnPar.texture=leftText2
        
        
        let rightBtnPar = scene?.childNode(withName: "right1") as! SKSpriteNode
        let rightText2 = SKTexture(imageNamed: "Layer1_right_btn1")
        rightBtnPar.texture=rightText2
        
    }
    
    
}
