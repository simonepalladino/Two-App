//
//  templateSpriteKitApp.swift
//  templateSpriteKit
//

//

import SwiftUI

@main
struct templateSpriteKitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
